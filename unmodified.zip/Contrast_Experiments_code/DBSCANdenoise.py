import open3d as o3d
import numpy as np


def read_ply(ply_file):
    """
    读取ASCII编码的.ply文件，提取x, y, z，并添加id
    """
    pcd = o3d.io.read_point_cloud(ply_file, format='ply')
    points = np.asarray(pcd.points)
    ids = np.arange(1, len(points) + 1)
    return pcd, points, ids


def denoise_and_sort_with_dbscan(pcd, points, ids, eps=0.05, min_points=10):
    """
    使用 DBSCAN 去噪，并返回保留点和噪声点的 ID
    """
    labels = np.array(pcd.cluster_dbscan(eps=eps, min_points=min_points, print_progress=True))

    # 非噪声点索引
    inlier_indices = np.where(labels != -1)[0]
    filtered_points = points[inlier_indices]
    filtered_ids = ids[inlier_indices]

    # 噪声点索引
    outlier_indices = np.where(labels == -1)[0]
    outlier_ids = ids[outlier_indices]

    return filtered_points, filtered_ids, outlier_ids


def save_denoised_point_cloud(filtered_points, filtered_ids, outlier_ids, output_ply_file, txt_file_path):
    """
    保存去噪后的点云，按照id升序排列，并保存被删除的ID
    """
    sorted_indices = np.argsort(filtered_ids)
    sorted_points = filtered_points[sorted_indices]
    sorted_ids = filtered_ids[sorted_indices]

    # 可视化颜色（全0）
    colors = np.zeros_like(sorted_points)
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(sorted_points)
    pcd.colors = o3d.utility.Vector3dVector(colors)

    o3d.io.write_point_cloud(output_ply_file, pcd, write_ascii=True)

    with open(txt_file_path, "w") as f:
        for id in outlier_ids:
            f.write(f"{id}\n")

    print(f"Denoised point cloud saved to {output_ply_file}")
    print(f"Removed IDs saved to {txt_file_path}")


# 使用示例
ply_file = "/home/acc/Desktop/dbscandenoise/toy2/toy2_ascii_xyz_withid.ply"
output_ply_file = "/home/acc/Desktop/dbscandenoise/toy2/toy2_ascii_xyz_withid_denoise.ply"
txt_file_path = "/home/acc/Desktop/dbscandenoise/toy2/removed_ids.txt"

# 参数：eps 控制邻域大小，min_points 控制密度
eps = 0.05
min_points = 10

# 读取点云
pcd, points, ids = read_ply(ply_file)

# DBSCAN 去噪
filtered_points, filtered_ids, outlier_ids = denoise_and_sort_with_dbscan(pcd, points, ids, eps, min_points)

# 保存结果
save_denoised_point_cloud(filtered_points, filtered_ids, outlier_ids, output_ply_file, txt_file_path)
