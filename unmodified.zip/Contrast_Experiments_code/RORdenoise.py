import open3d as o3d
import numpy as np
import os

def read_ply(ply_file):
    """
    读取ASCII编码的.ply文件，提取x, y, z，并添加id
    """
    pcd = o3d.io.read_point_cloud(ply_file, format='ply')
    points = np.asarray(pcd.points)
    ids = np.arange(1, len(points) + 1)
    return points, ids

def denoise_and_sort_with_ror(points, ids, radius=0.05, min_neighbors=10):
    """
    使用 Radius Outlier Removal (ROR) 去噪，并按id排序
    """
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)

    # 应用 ROR 去噪
    cl, inlier_indices = pcd.remove_radius_outlier(nb_points=min_neighbors, radius=radius)

    # 获取保留的点及其id
    filtered_points = points[inlier_indices]
    filtered_ids = ids[inlier_indices]

    # 获取被移除的点的id
    outlier_indices = np.setdiff1d(np.arange(len(points)), inlier_indices)
    outlier_ids = ids[outlier_indices]

    return filtered_points, filtered_ids, outlier_ids

def save_denoised_point_cloud(filtered_points, filtered_ids, output_ply_file, outlier_ids):
    """
    保存去噪后的点云（按id升序排序），并将移除的id写入.txt文件
    """
    sorted_indices = np.argsort(filtered_ids)
    sorted_points = filtered_points[sorted_indices]
    sorted_ids = filtered_ids[sorted_indices]

    # 保存PLY文件（仅保存xyz）
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(sorted_points)
    o3d.io.write_point_cloud(output_ply_file, pcd, write_ascii=True)

    # 保存移除的ID
    output_dir = '/home/acc/Desktop/rordenoise/toy'
    os.makedirs(output_dir, exist_ok=True)
    removed_ids_file = os.path.join(output_dir, 'removed_ids.txt')
    with open(removed_ids_file, 'w') as f:
        for id in outlier_ids:
            f.write(f"{id}\n")

    print(f"点云保存到：{output_ply_file}")
    print(f"移除的ID保存到：{removed_ids_file}")

# 示例运行
if __name__ == "__main__":
    ply_file = "/home/acc/Desktop/rordenoise/toy/toy_ascii_xyz_withid.ply"  # 输入的点云文件路径
    output_ply_file = "/home/acc/Desktop/rordenoise/toy/toy_ascii_xyz_withid_denoise.ply"  # 输出的去噪点云文件路径

    points, ids = read_ply(ply_file)
    filtered_points, filtered_ids, outlier_ids = denoise_and_sort_with_ror(points, ids, radius=0.05, min_neighbors=10)
    save_denoised_point_cloud(filtered_points, filtered_ids, output_ply_file, outlier_ids)
