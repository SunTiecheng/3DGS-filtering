import open3d as o3d
import numpy as np


def read_ply(ply_file):
    """
    读取ASCII编码的.ply文件，提取x, y, z，并添加id
    """
    # 读取点云文件
    pcd = o3d.io.read_point_cloud(ply_file, format='ply')

    # 获取点云数据
    points = np.asarray(pcd.points)

    # 生成id：从1开始的顺序号
    ids = np.arange(1, len(points) + 1)

    return points, ids


def denoise_and_sort(points, ids):
    """
    使用Statistical Outlier Removal (SOR) 滤波器去噪，并按id排序
    """
    # 创建一个PointCloud对象
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)

    # 应用Statistical Outlier Removal滤波器
    sor = pcd.remove_statistical_outlier(nb_neighbors=20, std_ratio=2.0)
    inlier_indices = sor[1]  # 留下的点的索引

    # 获取去噪后的点和它们的id
    filtered_points = points[inlier_indices]
    filtered_ids = ids[inlier_indices]

    # 获取去除的点（噪声）
    outlier_indices = np.setdiff1d(np.arange(len(points)), inlier_indices)
    outlier_ids = ids[outlier_indices]

    return filtered_points, filtered_ids, outlier_ids


def save_denoised_point_cloud(filtered_points, filtered_ids, outlier_ids, output_ply_file, txt_file_path):
    """
    保存去噪后的点云，按照id升序排列
    """
    # 按id排序
    sorted_indices = np.argsort(filtered_ids)
    sorted_points = filtered_points[sorted_indices]
    sorted_ids = filtered_ids[sorted_indices]

    # 将id添加到点云颜色作为可视化
    colors = np.zeros_like(sorted_points)  # 默认为黑色
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(sorted_points)

    # 根据id的排序给每个点设置颜色
    pcd.colors = o3d.utility.Vector3dVector(colors)

    # 保存排序后的点云
    o3d.io.write_point_cloud(output_ply_file, pcd, write_ascii=True)

    # 保存去噪后的点云ID（保存为txt文件）
    with open(txt_file_path, "w") as f:
        for id in outlier_ids:
            f.write(f"{id}\n")

    print(f"Denoised point cloud saved to {output_ply_file}")
    print(f"Removed IDs saved to {txt_file_path}")




# 使用示例
ply_file = "/home/acc/Desktop/sordenoise/airplane1/airplane_ascii_xyz_withid.ply"  # 输入的点云文件路径
output_ply_file = "/home/acc/Desktop/sordenoise/airplane1/airplane_ascii_xyz_withid_denoise.ply"  # 输出的去噪点云文件路径
txt_file_path = "/home/acc/Desktop/sordenoise/airplane1/removed_ids.txt"

# 读取点云文件
points, ids = read_ply(ply_file)

# 去噪并排序
filtered_points, filtered_ids, outlier_ids = denoise_and_sort(points, ids)

# 保存去噪后的点云和移除的点的id
save_denoised_point_cloud(filtered_points, filtered_ids, outlier_ids, output_ply_file, txt_file_path)

