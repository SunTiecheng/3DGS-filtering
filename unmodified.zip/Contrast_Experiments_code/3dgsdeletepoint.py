def remove_points_by_id(ply_file, id_txt_file, output_ply_file):
    # 读取要移除的id列表
    with open(id_txt_file, 'r') as f:
        remove_ids = set(int(line.strip()) for line in f if line.strip())

    with open(ply_file, 'r') as f:
        lines = f.readlines()

    # 分离 header 和 数据部分
    header = []
    data_start_index = 0
    for i, line in enumerate(lines):
        header.append(line)
        if line.strip() == 'end_header':
            data_start_index = i + 1
            break

    data_lines = lines[data_start_index:]

    # 处理数据：删除 id 命中的行
    retained_data = []
    for line in data_lines:
        parts = line.strip().split()
        if len(parts) < 4:
            continue  # 防止空行或格式错误
        point_id = int(parts[-1])  # id 是最后一列
        if point_id not in remove_ids:
            retained_data.append(line)

    # 更新 header 中的顶点数量
    for i, line in enumerate(header):
        if line.startswith('element vertex'):
            header[i] = f"element vertex {len(retained_data)}\n"
            break

    # 保存新的 .ply 文件
    with open(output_ply_file, 'w') as f:
        f.writelines(header)
        f.writelines(retained_data)

    print(f"处理完成，已移除 {len(remove_ids)} 个点，结果保存为：{output_ply_file}")


# 示例调用
ply_file = '/home/acc/Desktop/sordenoise/airplane1/airplane_ascii_with_id.ply'  # 输入的点云文件
id_txt_file = '/home/acc/Desktop/sordenoise/airplane1/removed_ids.txt'  # 你的.txt文件路径
output_ply_file = '/home/acc/Desktop/sordenoise/airplane1/filtered_output.ply'  # 输出文件路径

remove_points_by_id(ply_file, id_txt_file, output_ply_file)
