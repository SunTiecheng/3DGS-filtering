import numpy as np


def remove_id_from_ply(input_file, output_file):
    """从PLY文件中移除ID信息

    Args:
        input_file: 输入的PLY文件
        output_file: 输出的PLY文件
    """
    # 读取文件头部和数据
    header_lines = []
    data_lines = []
    vertex_count = 0

    with open(input_file, 'r') as f:
        # 读取头部信息
        while True:
            line = f.readline().strip()
            if line == 'end_header':
                break

            # 记录点的数量，但不修改它
            if line.startswith('element vertex'):
                vertex_count = int(line.split()[-1])
                header_lines.append(line)
            # 跳过ID属性声明
            elif line.startswith('property') and 'id' in line.lower():
                continue
            else:
                header_lines.append(line)

        # 读取数据部分
        data = np.loadtxt(f, dtype=np.float64)

    # 移除最后一列（ID列）
    data = data[:, :-1]

    # 写入新文件
    with open(output_file, 'w') as f:
        # 写入头部信息
        for line in header_lines:
            f.write(line + '\n')
        f.write('end_header\n')

        # 写入数据（不包含ID列）
        for row in data:
            f.write(' '.join([f'{x:.16f}' for x in row]) + '\n')


def check_file_structure(filename):
    """检查文件是否包含ID信息并打印相关信息"""
    has_id_property = False
    with open(filename, 'r') as f:
        # 检查头部
        while True:
            line = f.readline().strip()
            if line == 'end_header':
                break
            if 'property' in line and 'id' in line.lower():
                has_id_property = True
                print(f"找到ID属性声明: {line}")

        # 检查第一行数据
        first_line = f.readline().strip()
        num_columns = len(first_line.split())
        print(f"数据行的列数: {num_columns}")

    return has_id_property


if __name__ == "__main__":
    # 使用示例
    input_file = "/home/acc/Desktop/sordenoise/airplane1/filtered_output.ply"  # 输入文件
    output_file = "/home/acc/Desktop/sordenoise/airplane1/airplane_denoise.ply"  # 输出文件

    # 首先检查文件结构
    print("检查输入文件结构...")
    has_id = check_file_structure(input_file)

    if has_id:
        print("开始处理文件...")
        remove_id_from_ply(input_file, output_file)
        print("处理完成！")
        print(f"已移除ID信息并保存至: {output_file}")
    else:
        print("警告：未在文件中检测到ID属性，请确认文件格式是否正确。")