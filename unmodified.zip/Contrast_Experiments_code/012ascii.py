# 点云文件二进制编码转ASCII
import struct
import os

def convert_binary_ply_to_ascii(binary_ply_path, ascii_ply_path):
    """
    Convert a binary-encoded PLY file to ASCII format.

    Parameters:
        binary_ply_path (str): Path to the binary PLY file.
        ascii_ply_path (str): Path to save the converted ASCII PLY file.
    """
    with open(binary_ply_path, 'rb') as f:
        # Read the header
        header = []
        while True:
            line = f.readline().decode('utf-8', errors='ignore')
            header.append(line)
            if line.startswith("end_header"):
                break

        # Parse header to determine the structure
        is_binary = False
        num_vertices = 0
        properties = []
        for line in header:
            if "format binary" in line:
                is_binary = True
            if line.startswith("element vertex"):
                num_vertices = int(line.split()[-1])
            if line.startswith("property"):
                properties.append(line.split()[1])  # e.g., float, uchar

        if not is_binary:
            raise ValueError("The input file is not in binary format.")

        # Write the ASCII header
        with open(ascii_ply_path, 'w') as ascii_file:
            for line in header:
                ascii_file.write(line.replace("binary_little_endian", "ascii"))

        # Read binary data and convert to ASCII
        with open(ascii_ply_path, 'a') as ascii_file:
            for _ in range(num_vertices):
                data = []
                for prop in properties:
                    if prop == "float":
                        data.append(struct.unpack('<f', f.read(4))[0])
                    elif prop == "uchar":
                        data.append(struct.unpack('<B', f.read(1))[0])
                    elif prop == "int":
                        data.append(struct.unpack('<i', f.read(4))[0])
                    # Add other property types if necessary
                ascii_file.write(" ".join(map(str, data)) + "\n")

    print(f"Conversion complete. ASCII PLY file saved at: {ascii_ply_path}")


# Example usage
binary_ply_path = "/home/acc/Desktop/sordenoise/airplane.ply"
ascii_ply_path = "/home/acc/Desktop/sordenoise/airplane1/airplane_ascii.ply"

convert_binary_ply_to_ascii(binary_ply_path, ascii_ply_path)
