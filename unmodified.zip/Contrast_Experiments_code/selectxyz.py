def extract_xyz_with_id(input_ply, output_ply):
    with open(input_ply, 'r') as f:
        lines = f.readlines()

    header = []
    data_start_idx = 0
    xyz_props = ['property float x', 'property float y', 'property float z']

    # 处理header：保留必要的结构 + x,y,z声明
    for i, line in enumerate(lines):
        header.append(line)
        if line.strip() == 'end_header':
            data_start_idx = i + 1
            break

    # 构造新的header，仅保留x y z并添加id字段
    new_header = []
    for line in header:
        if line.startswith('property'):
            if line.strip() in xyz_props:
                new_header.append(line)
        elif line.startswith('element vertex'):
            point_count = int(line.strip().split()[-1])
            new_header.append(line)
        elif line.strip() == 'end_header':
            new_header.append('property int id\n')  # 添加id字段
            new_header.append('end_header\n')
        else:
            new_header.append(line)

    # 处理数据部分：提取xyz并添加id
    data_lines = lines[data_start_idx:]
    output_data = []
    for idx, line in enumerate(data_lines):
        cols = line.strip().split()
        x, y, z = cols[:3]
        id_val = idx + 1  # 从1开始编号
        output_data.append(f"{x} {y} {z} {id_val}\n")

    # 写入新文件
    with open(output_ply, 'w') as f:
        f.writelines(new_header)
        f.writelines(output_data)

    print(f"处理完成，保存至 {output_ply}")


# 使用示例
input_ply = '/home/acc/Desktop/sordenoise/airplane1/airplane_ascii.ply'  # 原始点云路径
output_ply = '/home/acc/Desktop/sordenoise/airplane1/airplane_ascii_xyz_withid.ply'  # 输出路径
extract_xyz_with_id(input_ply, output_ply)