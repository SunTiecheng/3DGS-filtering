import os
import glob


def add_id_to_ply(input_path, output_path):
    """
    为PLY文件添加ID列
    """
    with open(input_path, 'r') as f:
        lines = f.readlines()

    # 找到header结束的位置
    header_end = 0
    vertex_count = 0
    for i, line in enumerate(lines):
        if line.startswith('element vertex'):
            vertex_count = int(line.split()[-1])
        if line.startswith('end_header'):
            header_end = i
            break

    # 构建新的文件内容
    new_content = []

    # 复制header到end_header之前的内容
    new_content.extend(lines[:header_end])

    # 添加ID属性声明
    new_content.append('property int id\n')

    # 添加end_header
    new_content.append('end_header\n')

    # 处理数据部分，添加ID
    for i, line in enumerate(lines[header_end + 1:header_end + 1 + vertex_count], 1):
        new_content.append(f"{line.strip()} {i}\n")

    # 写入新文件
    with open(output_path, 'w') as f:
        f.writelines(new_content)


def batch_process_ply_files(input_dir, output_dir=None):
    """
    批量处理PLY文件，添加ID列
    """
    # 如果没有指定输出目录，使用输入目录
    if output_dir is None:
        output_dir = input_dir

    # 确保输出目录存在
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # 获取所有ASCII PLY文件
    ply_files = glob.glob(os.path.join(input_dir, "*.ply"))
    total_files = len(ply_files)

    print(f"找到 {total_files} 个PLY文件")

    # 处理每个文件
    for i, ply_file in enumerate(ply_files, 1):
        filename = os.path.basename(ply_file)
        output_filename = f"{os.path.splitext(filename)[0]}_with_id.ply"
        output_path = os.path.join(output_dir, output_filename)

        print(f"[{i}/{total_files}] 正在处理: {filename}")

        try:
            add_id_to_ply(ply_file, output_path)
            print(f"    已添加ID并保存为: {output_filename}")
        except Exception as e:
            print(f"    处理失败: {str(e)}")


if __name__ == "__main__":
    # 设置输入和输出目录
    input_dir = "/home/acc/Desktop/sordenoise/airplane1"  # 修改为您的PLY文件目录
    output_dir = "/home/acc/Desktop/sordenoise/airplane1"  # 修改为您想保存处理后文件的目录

    # 执行批量处理
    batch_process_ply_files(input_dir, output_dir)