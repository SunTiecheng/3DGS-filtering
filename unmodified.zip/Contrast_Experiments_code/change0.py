import os


def replace_normal_with_zero(ply_file, output_ply_file):
    # 检查输入文件是否存在
    if not os.path.exists(ply_file):
        print(f"错误：输入文件 {ply_file} 不存在！")
        return

    with open(ply_file, 'r') as f:
        lines = f.readlines()

    # 分离 header 和 数据部分
    header = []
    data_start_index = 0
    for i, line in enumerate(lines):
        header.append(line)
        if line.strip() == 'end_header':
            data_start_index = i + 1
            break

    data_lines = lines[data_start_index:]

    # 替换第3、4、5列的法向量数据为0
    modified_data = []
    for line in data_lines:
        parts = line.strip().split()
        if len(parts) >= 5:
            parts[3] = '0'  # nx
            parts[4] = '0'  # ny
            parts[5] = '0'  # nz
        modified_data.append(' '.join(parts) + '\n')

    # 更新 header 中的顶点数量和数据部分
    for i, line in enumerate(header):
        if line.startswith('element vertex'):
            header[i] = f"element vertex {len(modified_data)}\n"
            break

    # 确认输出路径存在
    output_dir = os.path.dirname(output_ply_file)
    if not os.path.exists(output_dir):
        print(f"错误：输出目录 {output_dir} 不存在！")
        return

    # 保存新的 .ply 文件
    with open(output_ply_file, 'w') as f:
        f.writelines(header)
        f.writelines(modified_data)

    print(f"法向量数据已替换，结果保存为：{output_ply_file}")


# 示例调用
ply_file = '/home/acc/Desktop/sordenoise/airplane1/airplane_denoise.ply'  # 输入的点云文件路径
output_ply_file = '/home/acc/Desktop/sordenoise/airplane1/airplane_denoise_complete.ply'  # 输出文件路径

replace_normal_with_zero(ply_file, output_ply_file)
