'体素化，用于choose1.py之后，voxel_resolution超参数可用于调整体素精度'
import numpy as np
import pandas as pd

def read_ply(file_path):
    """读取 PLY 文件，分离头部和数据部分"""
    with open(file_path, 'r') as f:
        header = []
        data_start = 0
        for i, line in enumerate(f):
            header.append(line)
            if line.strip() == "end_header":
                data_start = i + 1
                break
        data = pd.read_csv(file_path, skiprows=data_start, sep=' ', header=None)
    return header, data

def normalize_and_voxelize(data, voxel_resolution):
    """归一化坐标并进行体素化，同时保留ID"""
    # 提取 xyz 坐标和 ID 列
    xyz = data.iloc[:, :3].values
    attributes = data.iloc[:, 3:-1].values  # 其他属性
    ids = data.iloc[:, -1].values.astype(int)  # 强制将 ID 列转换为 int

    # 归一化到 [0, 1] 区间
    xyz_min = xyz.min(axis=0)
    xyz_max = xyz.max(axis=0)
    xyz_normalized = (xyz - xyz_min) / (xyz_max - xyz_min)

    # 缩放到体素网格中
    voxel_grid_coords = (xyz_normalized * voxel_resolution).astype(int)

    # 拼接体素坐标、属性和ID
    voxelized_data = np.hstack((voxel_grid_coords, attributes, ids.reshape(-1, 1)))
    return voxelized_data

def write_ply(output_path, header, voxelized_data):
    """将处理后的数据保存为 PLY 文件"""
    with open(output_path, 'w') as f:
        for line in header:
            f.write(line)
        for row in voxelized_data:
            # 将每一列数据写入文件，确保ID为整数
            row = list(row)
            row[:-1] = map(str, row[:-1])  # 保留其他列为字符串
            row[-1] = str(int(row[-1]))   # 强制将 ID 转为整数
            f.write(' '.join(row) + '\n')

# 参数设置
input_files = [
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/xyz_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/nxyz_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fdc012_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre012_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre345_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre678_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre91011_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre121314_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre151617_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre181920_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre212223_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre242526_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre272829_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre303132_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre333435_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre363738_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre394041_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre424344_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre4344op_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/scale012_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/rot012_ascii.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/拆分/rot123_ascii.ply'





]  # 输入 PLY 文件路径列表
output_dir = '/home/acc/Desktop/带背景高斯点云/toy2/体素化/'  # 输出文件夹路径
voxel_resolution = 7168  # 设置体素网格分辨率

# 执行处理流程
for input_ply in input_files:
    # 提取文件名用于输出
    file_name = input_ply.split('/')[-1].replace('.ply', '_voxel.ply')
    output_ply = f"{output_dir}{file_name}"

    # 读取和处理
    header, data = read_ply(input_ply)
    voxelized_data = normalize_and_voxelize(data, voxel_resolution)
    write_ply(output_ply, header, voxelized_data)

    print(f"体素化后的点云（含ID）已保存至: {output_ply}")
