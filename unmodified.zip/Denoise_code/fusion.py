'用于在delete_12lie.py后的对齐'
import pandas as pd
from functools import reduce

def read_ply(file_path):
    """读取 PLY 文件并分离头部和数据部分"""
    with open(file_path, 'r') as f:
        header = []
        data_start = 0
        for i, line in enumerate(f):
            header.append(line)
            if line.strip() == "end_header":
                data_start = i + 1
                break
        data = pd.read_csv(file_path, skiprows=data_start, sep=' ', header=None)
    return header, data

def write_ply(file_path, header, data):
    """将数据写回 PLY 文件，保留 ASCII 格式"""
    with open(file_path, 'w') as f:
        for line in header:
            f.write(line)
        for row in data.itertuples(index=False):
            f.write(' '.join(map(str, row)) + '\n')

# # 文件路径列表
# file_paths = [
#     '/home/acc/Desktop/airplane dataset/结果/xyz_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/fdc012_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/fre012_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/fre345_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/fre678_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/fre91011_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/fre121314_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/fre151617_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/fre181920_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/fre212223_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/fre242526_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/fre272829_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/fre303132_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/fre333435_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/fre363738_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/fre394041_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/fre424344_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/opacity_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/scale012_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/rot012_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/airplane dataset/结果/rot3_ascii_voxeltopc.ply',
# ]

# file_paths = [
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/xyz_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/fdc012_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/fre012_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/fre345_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/fre678_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/fre91011_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/fre121314_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/fre151617_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/fre181920_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/fre212223_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/fre242526_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/fre272829_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/fre303132_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/fre333435_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/fre363738_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/fre394041_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/fre424344_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/opacity_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/scale012_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/rot012_ascii_voxeltopc.ply',
#     '/home/acc/Desktop/带背景高斯点云/airplane3/对齐/rot3_ascii_voxeltopc.ply'
# ]

file_paths = [
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/xyz_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fdc012_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre012_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre345_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre678_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre91011_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre121314_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre151617_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre181920_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre212223_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre242526_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre272829_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre303132_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre333435_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre363738_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre394041_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre424344_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/opacity_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/scale012_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/rot012_ascii_voxeltopc.ply',
    '/home/acc/Desktop/带背景高斯点云/toy2/对齐/rot3_ascii_voxeltopc.ply'

]

# 读取所有文件并设置列名
columns_list = [
    ['x', 'y', 'z', 'ID'],
    ['f_dc_0', 'f_dc_1', 'f_dc_2', 'ID'],
    ['f_rest_0', 'f_rest_1', 'f_rest_2', 'ID'],
    ['f_rest_3', 'f_rest_4', 'f_rest_5', 'ID'],
    ['f_rest_6', 'f_rest_7', 'f_rest_8', 'ID'],
    ['f_rest_9', 'f_rest_10', 'f_rest_11', 'ID'],
    ['f_rest_12', 'f_rest_13', 'f_rest_14', 'ID'],
    ['f_rest_15', 'f_rest_16', 'f_rest_17', 'ID'],
    ['f_rest_18', 'f_rest_19', 'f_rest_20', 'ID'],
    ['f_rest_21', 'f_rest_22', 'f_rest_23', 'ID'],
    ['f_rest_24', 'f_rest_25', 'f_rest_26', 'ID'],
    ['f_rest_27', 'f_rest_28', 'f_rest_29', 'ID'],
    ['f_rest_30', 'f_rest_31', 'f_rest_32', 'ID'],
    ['f_rest_33', 'f_rest_34', 'f_rest_35', 'ID'],
    ['f_rest_36', 'f_rest_37', 'f_rest_38', 'ID'],
    ['f_rest_39', 'f_rest_40', 'f_rest_41', 'ID'],
    ['f_rest_42', 'f_rest_43', 'f_rest_44', 'ID'],
    ['opacity', 'ID'],
    ['scale_0', 'scale_1', 'scale_2', 'ID'],
    ['rot_0', 'rot_1', 'rot_2', 'ID'],
    ['rot_3', 'ID'],
]

# 将所有文件读取为 DataFrame
dataframes = []
for file_path, columns in zip(file_paths, columns_list):
    _, data = read_ply(file_path)
    data.columns = columns
    dataframes.append(data)

# 合并所有 DataFrame
merged_data = reduce(lambda left, right: pd.merge(left, right, on='ID', how='inner'), dataframes)

# 删除 ID 列
merged_data = merged_data.drop(columns=['ID'])

# 更新头部信息
updated_header = [
    "ply\n",
    "format ascii 1.0\n",
    f"element vertex {len(merged_data)}\n"
] + [f"property float {col}\n" for col in merged_data.columns] + ["end_header\n"]

# 输出合并后的文件
output_path = '/home/acc/Desktop/带背景高斯点云/toy2/对齐/nonxyz.ply'
write_ply(output_path, updated_header, merged_data)

print(f"合并后的点云已保存至: {output_path}")
