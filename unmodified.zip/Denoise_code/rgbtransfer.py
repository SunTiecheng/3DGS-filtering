import os
from PIL import Image
import numpy as np

# 输入和输出文件夹路径
input_folder = 'C:/Users/86189/Desktop/airplane'
output_folder = 'C:/Users/86189/Desktop/airplane_gt'

# 归一化值 0.8 转换为 8位像素值
replacement_color = (204, 204, 204)  # 0.8 * 255 ≈ 204

# 确保输出文件夹存在
os.makedirs(output_folder, exist_ok=True)

# 处理每张图片
for filename in os.listdir(input_folder):
    if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
        img_path = os.path.join(input_folder, filename)
        img = Image.open(img_path).convert('RGB')

        # 转换为数组进行处理
        img_array = np.array(img)
        mask = np.all(img_array == [0, 0, 0], axis=-1)
        img_array[mask] = replacement_color

        # 转换回图像并保存
        new_img = Image.fromarray(img_array)
        new_img.save(os.path.join(output_folder, filename))

print("所有图片处理完成 ✅")
