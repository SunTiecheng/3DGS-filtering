"把nxnynz三列全0数据添加到数据文件当中"


# 导入必要模块
import pandas as pd

# 定义函数以读取 PLY 文件
def read_ply(file_path):
    """读取 PLY 文件并分离头部和数据部分"""
    with open(file_path, 'r') as f:
        header = []
        data_start = 0
        for i, line in enumerate(f):
            header.append(line)
            if line.strip() == "end_header":
                data_start = i + 1
                break
        data = pd.read_csv(file_path, skiprows=data_start, sep=' ', header=None)
    return header, data

# 定义函数以写入 PLY 文件
def write_ply(file_path, header, data):
    """将数据写回 PLY 文件，保留 ASCII 格式"""
    with open(file_path, 'w') as f:
        for line in header:
            f.write(line)
        for row in data.itertuples(index=False):
            f.write(' '.join(map(str, row)) + '\n')

# 文件路径
file_path = '/home/acc/Desktop/带背景高斯点云/formula1/对齐/nonxyz.ply'

# 读取文件
header, data = read_ply(file_path)

# 新增三列值全部为 0 的数据，插入到第 4, 5, 6 列
data.insert(3, 'new_col_1', 0)  # 第 4 列
data.insert(4, 'new_col_2', 0)  # 第 5 列
data.insert(5, 'new_col_3', 0)  # 第 6 列

# 修改头部信息，添加三列描述
# updated_header = []
# for line in header:
#     if line.startswith("element vertex"):
#         updated_header.append(f"element vertex {len(data)}\n")
#     elif line.startswith("end_header"):
#         updated_header.extend([
#
#             "end_header\n"
#         ])
#     else:
#         updated_header.append(line)
updated_header = []
for line in header:
    if line.startswith("element vertex"):
        updated_header.append(f"element vertex {len(data)}\n")
    elif line.startswith("property") and 'z' in line:
        # 在 z 属性之后插入 nx, ny, nz
        updated_header.append(line)
        updated_header.append("property float nx\n")
        updated_header.append("property float ny\n")
        updated_header.append("property float nz\n")
    elif line.strip() == "end_header":
        updated_header.append("end_header\n")
    else:
        updated_header.append(line)

# 输出文件路径
output_path = '/home/acc/Desktop/带背景高斯点云/formula1/对齐/car_ascii_re.ply'

# 写回处理后的文件
write_ply(output_path, updated_header, data)

output_path
