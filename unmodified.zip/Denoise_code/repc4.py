import torch
import MinkowskiEngine as ME
from pcc_model import PCCModel
from scipy.spatial import cKDTree
import numpy as np
import os
import time


def read_ply_with_id(file_path):
    """
    读取带ID的点云数据
    :param file_path: 输入 PLY 文件路径
    :return: xyz 坐标 (N, 3)，ID 列 (N, 1)
    """
    coords = []
    ids = []
    with open(file_path, 'r') as f:
        header_ended = False
        for line in f:
            if header_ended:
                values = line.strip().split()
                if len(values) >= 4:
                    coords.append(list(map(float, values[:3])))  # 提取三维属性坐标
                    ids.append(int(float(values[3])))  # 提取 ID
            elif line.startswith("end_header"):
                header_ended = True
    coords = torch.tensor(coords).float()
    ids = torch.tensor(ids).int()
    return coords, ids


def write_ply_with_id(output_path, coords, ids, input_ply_path):
    """
    将点云的 xyz 和 ID 写入 PLY 文件，并动态保持与输入点云文件头部一致
    :param output_path: 输出 PLY 文件路径
    :param coords: 点云坐标 (N, 3)
    :param ids: 点云 ID (N, 1)
    :param input_ply_path: 输入 PLY 文件路径，用于提取头部信息
    """
    with open(input_ply_path, 'r') as f:
        head_lines = []
        header_ended = False

        for line in f:
            if header_ended:
                break
            head_lines.append(line)
            if line.startswith("end_header"):
                header_ended = True

    with open(output_path, 'w') as f:
        # 写入头部
        for line in head_lines:
            if line.startswith("element vertex"):
                f.write(f"element vertex {coords.shape[0]}\n")  # 更新点数
            else:
                f.write(line)

        # 写入点云数据
        for i in range(coords.shape[0]):
            x, y, z = coords[i].tolist()
            f.write(f"{x} {y} {z} {ids[i].item()}\n")


def save_compressed_data(filename, sparse_tensor, num_points):
    """
    保存压缩后的数据
    :param filename: 文件名
    :param sparse_tensor: 稀疏张量
    :param num_points: 各层的点数列表
    """
    # 保存坐标
    np.save(f"{filename}_coords.npy", sparse_tensor.C.cpu().numpy())

    # 保存特征
    np.save(f"{filename}_feats.npy", sparse_tensor.F.cpu().numpy())

    # 保存点数信息
    np.save(f"{filename}_num_points.npy", np.array(num_points))

    # 保存tensor_stride信息
    np.save(f"{filename}_tensor_stride.npy", sparse_tensor.tensor_stride)

    print(f"压缩数据已保存至 {filename}_*.npy")


def load_compressed_data(filename, device):
    """
    加载压缩后的数据
    :param filename: 文件名
    :param device: 设备
    :return: 稀疏张量和点数列表
    """
    # 加载坐标
    coords = torch.tensor(np.load(f"{filename}_coords.npy")).to(device)

    # 加载特征
    feats = torch.tensor(np.load(f"{filename}_feats.npy")).to(device)

    # 加载点数信息
    num_points = np.load(f"{filename}_num_points.npy").tolist()

    # 加载tensor_stride信息
    tensor_stride = np.load(f"{filename}_tensor_stride.npy").tolist()

    # 创建稀疏张量
    sparse_tensor = ME.SparseTensor(
        features=feats,
        coordinates=coords,
        tensor_stride=tensor_stride,
        device=device
    )

    return sparse_tensor, num_points


# 主函数部分 - 分为编码和解码两个独立过程

def encoder_process(model_path, input_ply_path, output_dir):
    """
    编码过程
    :param model_path: 模型路径
    :param input_ply_path: 输入点云路径
    :param output_dir: 输出目录
    """
    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)

    # 设置输出文件名前缀
    filename_base = os.path.join(output_dir, os.path.basename(input_ply_path).split('.')[0])
    encoder_output_ply_path = f"{filename_base}_encoder.ply"

    # 加载模型
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = PCCModel().to(device)
    checkpoint = torch.load(model_path, map_location=device)
    model.load_state_dict(checkpoint['model'])
    model.eval()

    # 加载输入点云（包括ID）
    coords, ids = read_ply_with_id(input_ply_path)

    # 构建稀疏张量
    features = torch.ones((coords.shape[0], 1)).to(device)
    batch_id = torch.zeros(coords.shape[0], dtype=torch.int32).unsqueeze(1)
    coords_with_batch = torch.cat([batch_id, coords.int()], dim=1)
    sparse_input = ME.SparseTensor(features=features, coordinates=coords_with_batch, device=device)

    # 获取 encoder 的输出
    with torch.no_grad():
        encoder_outputs = model.encoder(sparse_input)
        out2 = encoder_outputs[0]  # encoder 的最后一层输出

        # 获取各层的点数
        num_points = [len(gt) for gt in encoder_outputs[1:] + [sparse_input]]

    # 保存压缩数据（这是关键 - 保存需要传递给解码器的所有信息）
    save_compressed_data(filename_base, out2, num_points)

    # 提取下采样点云的坐标并保存为PLY（仅用于可视化）
    out2_coords = out2.C.cpu().numpy()[:, 1:]  # 去掉 batch_id

    # 匹配下采样点云与输入点云
    input_coords = coords.numpy()
    kdtree = cKDTree(input_coords)

    # 为下采样点分配ID（与原始流程相同）
    k = 10
    used_ids = set()
    id_mapping = []

    for out_coord in out2_coords:
        assigned = False
        while not assigned:
            distances, indices = kdtree.query(out_coord, k=k)
            for neighbor_index in indices:
                candidate_id = ids[neighbor_index].item()
                if candidate_id not in used_ids:
                    id_mapping.append(candidate_id)
                    used_ids.add(candidate_id)
                    assigned = True
                    break
            if not assigned:
                k += 1

    # 对点云按 ID 进行排序
    sorted_indices = np.argsort(id_mapping)
    sorted_coords = out2_coords[sorted_indices]
    sorted_ids = np.array(id_mapping)[sorted_indices]

    # 保存带 ID 的下采样点云
    write_ply_with_id(encoder_output_ply_path, torch.tensor(sorted_coords),
                      torch.tensor(sorted_ids, dtype=torch.int32), input_ply_path)
    print(f"Encoder 下采样后的点云已保存至: {encoder_output_ply_path}")

    return filename_base


def decoder_process(model_path, compressed_data_prefix, input_ply_path, output_ply_path, rho=1.0):
    """
    解码过程
    :param model_path: 模型路径
    :param compressed_data_prefix: 压缩数据前缀
    :param input_ply_path: 输入点云路径（用于获取原始ID）
    :param output_ply_path: 输出点云路径
    :param rho: 输出点数与输入点数的比例
    """
    # 加载模型
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = PCCModel().to(device)
    checkpoint = torch.load(model_path, map_location=device)
    model.load_state_dict(checkpoint['model'])
    model.eval()

    # 加载原始点云（仅用于获取ID）
    coords, ids = read_ply_with_id(input_ply_path)

    # 加载压缩数据
    y, num_points = load_compressed_data(compressed_data_prefix, device)

    # 更新最后一层点数（应用rho因子）
    num_points[-1] = int(rho * num_points[-1])
    nums_list = [[num] for num in num_points]

    # 解码
    with torch.no_grad():
        # 使用量化后的特征
        y_q, _ = model.get_likelihood(y, quantize_mode="symbols")
        # 解码
        out_cls_list, out = model.decoder(y_q, nums_list, ground_truth_list=[None] * 3, training=False)

    # 提取重建点云的坐标
    reconstructed_coords = out.C.cpu().numpy()[:, 1:]  # 排除 batch_id 列

    # 最近邻匹配：确保点数一致并准确对应
    input_coords = coords.numpy()

    # 构建 KD 树
    kdtree = cKDTree(reconstructed_coords)
    distances, indices = kdtree.query(input_coords, k=1)

    # 确保每个输入点都有唯一对应的重建点
    matched_coords = reconstructed_coords[indices]
    matched_ids = ids

    # 保存重建点云
    write_ply_with_id(output_ply_path, torch.tensor(matched_coords), matched_ids, input_ply_path)
    print(f"重建点云已保存至: {output_ply_path}")


# 示例调用
if __name__ == "__main__":
    # 配置参数
    base_filename = "xyz"
    #base_filename = "fdc012"
    #base_filename = "fre012"
    #base_filename = "fre345"
    #base_filename = "fre678"
    #base_filename = "fre91011"
    #base_filename = "fre121314"
    #base_filename = "fre151617"
    #base_filename = "fre181920"
    #base_filename = "fre212223"
    #base_filename = "fre242526"
    #base_filename = "fre272829"
    #base_filename = "fre303132"
    #base_filename = "fre333435"
    #base_filename = "fre363738"
    #base_filename = "fre394041"
    #base_filename = "fre424344"
    #base_filename = "fre4344op"
    base_filename = "scale012"
    #base_filename = "rot012"
    #base_filename = "rot123"
    model_path = f"/home/acc/Desktop/PCGCv2-master (copy)/ckpts/r7_0.4bpp.pth"
    input_ply_path = f"/home/acc/Desktop/带背景高斯点云/formula1/体素化后去重/{base_filename}_ascii_voxel_norp.ply"
    output_dir = f"/home/acc/Desktop/带背景高斯点云/formula1/encoder/"

    # 步骤1：编码过程 - 保存压缩数据
    compressed_data_prefix = encoder_process(model_path, input_ply_path, output_dir)

    # 步骤2：解码过程 - 加载压缩数据并重建点云
    output_ply_path = f"/home/acc/Desktop/带背景高斯点云/formula1/点云重建后/{base_filename}_ascii_voxel_re.ply"
    os.makedirs(os.path.dirname(output_ply_path), exist_ok=True)
    decoder_process(model_path, compressed_data_prefix, input_ply_path, output_ply_path, rho=1.0)