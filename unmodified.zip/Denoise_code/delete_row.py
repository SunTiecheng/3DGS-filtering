"用于devoxelization.py后的删除rot123.py以及fre4344op.py的前两列"
"该脚本不完善，记得手动删除输出文件中的head的rot12与fre4344"
file_path = '/home/acc/Desktop/带背景高斯点云/formula1/对齐/rot123_ascii_voxeltopc.ply'
output_path = '/home/acc/Desktop/带背景高斯点云/formula1/对齐/rot3_ascii_voxeltopc.ply'
# file_path = '/home/acc/Desktop/带背景高斯点云/formula1/对齐/fre4344op_ascii_voxeltopc.ply'
# output_path = '/home/acc/Desktop/带背景高斯点云/formula1/对齐/opacity_ascii_voxeltopc.ply'
with open(file_path, 'r') as file:
    lines = file.readlines()

# Find the line where the header ends
header_end_index = lines.index('end_header\n') + 1

# Process the data part
processed_lines = lines[:header_end_index]  # Keep the header unchanged

# Iterate over the vertex data and remove the first two columns
for line in lines[header_end_index:]:
    parts = line.split()
    # Keep only the third (z) coordinate and the ID
    new_line = f"{parts[2]} {parts[3]}\n"
    processed_lines.append(new_line)

# Save the modified data to a new file
with open(output_path, 'w') as file:
    file.writelines(processed_lines)

print(f"Processed file saved at: {output_path}")
