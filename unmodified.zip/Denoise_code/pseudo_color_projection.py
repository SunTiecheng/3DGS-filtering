import numpy as np
import open3d as o3d
import matplotlib.pyplot as plt
import os

# =============== 用户配置部分 - 在这里修改您的参数 ===============
# 输入点云文件路径
INPUT_FILE = "/home/acc/Desktop/带背景高斯点云/airplane/点云重建前/merged_ascii.ply"  # 请修改为您的输入文件路径

# 输出彩色点云文件路径
OUTPUT_FILE = "/home/acc/Desktop/带背景高斯点云/airplane/点云重建前/merged_ascii_color.ply"  # 请修改为您的输出文件路径

# 要可视化的属性索引（从0开始计数，如0表示第一个非XYZ属性）
ATTRIBUTE_INDEX = 3  # 请修改为您想要的属性索引

# 颜色映射名称 (可选: 1viridis, 2plasma, 3inferno, magma, coolwarm, 4jet, rainbow, Blues, RdBu等)
COLORMAP_NAME = "Reds_r"  # 请修改为您想要的颜色映射

# "序列型 (Sequential)": ['viridis', 'plasma', 'inferno', 'magma', 'cividis', 'Blues', 'Greens', 'Reds',
#                         'YlOrBr'],
# "发散型 (Diverging)": ['coolwarm', 'RdBu', 'RdYlBu', 'RdYlGn', 'PuOr', 'BrBG'],
# "循环型 (Cyclic)": ['twilight', 'twilight_shifted', '5hsv'],
# "定性型 (Qualitative)": ['Pastel1', 'Pastel2', '6Paired', 'S7et1', 'Set2', 'tab10', 'tab20']
# # ===============================================================

def read_ascii_point_cloud(filename):
    """读取ASCII格式的点云文件，提取坐标和属性"""
    try:
        # 读取文件并解析头部信息
        with open(filename, 'r') as f:
            lines = f.readlines()

        # 查找头部信息结束位置
        header_end = 0
        header_lines = []
        for i, line in enumerate(lines):
            if line.startswith('#') or line.startswith('//') or line.startswith(';') or line.startswith(
                    'ply') or line.startswith('format') or line.startswith('element') or line.startswith(
                    'property') or line.startswith('end_header'):
                header_lines.append(line)
                header_end = i + 1
            elif not line.strip():  # 空行可能是头部的一部分
                header_end = i + 1
            else:
                break

        # 解析头部以确定列的含义
        header = ''.join(header_lines)

        # 尝试从头部确定字段名称
        field_names = extract_field_names(header)

        # 处理数据部分
        data_lines = lines[header_end:]
        data = []
        for line in data_lines:
            if line.strip():  # 跳过空行
                values = line.strip().split()
                if values:  # 确保行不为空
                    data.append([float(v) for v in values])

        # 转换为numpy数组
        if not data:
            raise ValueError("点云文件不包含有效数据")

        point_data = np.array(data)

        # 提取坐标和所有属性
        xyz = point_data[:, 0:3]
        attributes = {}

        # 如果有足够的列，假定其他列是属性
        if point_data.shape[1] > 3:
            # 如果成功解析了字段名称，则使用它们
            if field_names and len(field_names) >= point_data.shape[1]:
                for i in range(3, point_data.shape[1]):
                    attr_name = field_names[i] if i < len(field_names) else f"attr_{i - 3}"
                    attributes[attr_name] = point_data[:, i]
            else:
                # 默认情况下，为属性列分配通用名称
                for i in range(3, point_data.shape[1]):
                    attributes[f"attr_{i - 3}"] = point_data[:, i]

        return xyz, attributes, field_names

    except Exception as e:
        print(f"读取点云文件时出错: {e}")
        return None, None, None


def extract_field_names(header):
    """尝试从头部提取字段名称"""
    field_names = []

    # 处理PLY格式
    if "ply" in header:
        properties = []
        for line in header.split('\n'):
            if line.strip().startswith("property"):
                parts = line.strip().split()
                if len(parts) >= 3:
                    properties.append(parts[-1])
        if properties:
            return properties

    # 处理其他常见格式
    for line in header.split('\n'):
        line = line.strip()
        # 移除注释前缀
        if line.startswith('#'):
            line = line[1:].strip()
        elif line.startswith('//'):
            line = line[2:].strip()
        elif line.startswith(';'):
            line = line[1:].strip()

        # 查找关键字
        keywords = ['FIELDS', 'COLUMNS', 'fields', 'columns']
        found = False
        for keyword in keywords:
            if keyword in line:
                parts = line.split(keyword, 1)[1].strip().split()
                if parts:
                    field_names = parts
                    found = True
                    break

        if found:
            break

        # 如果没有关键字但行看起来像是字段列表
        if not field_names and len(line.split()) >= 3:
            potential_fields = line.split()
            # 验证前三个是否可能是x,y,z
            if any(x in potential_fields[0].lower() for x in ['x', '0']):
                if any(y in potential_fields[1].lower() for y in ['y', '1']):
                    if any(z in potential_fields[2].lower() for z in ['z', '2']):
                        field_names = potential_fields

    return field_names


def normalize_values(values):
    """将数据归一化到[0,1]范围"""
    min_val = np.min(values)
    max_val = np.max(values)

    if max_val > min_val:
        normalized = (values - min_val) / (max_val - min_val)
    else:
        normalized = np.zeros_like(values)

    return normalized, min_val, max_val


def apply_colormap(values, colormap_name='viridis'):
    """应用指定的颜色映射"""
    cmap = plt.get_cmap(colormap_name)
    normalized_values, min_val, max_val = normalize_values(values)
    colors = cmap(normalized_values)[:, :3]  # 排除alpha通道
    return colors, min_val, max_val


def visualize_point_cloud_with_attribute(points, values, attribute_name, colormap_name='viridis'):
    """用属性的伪彩色可视化点云"""
    # 创建Open3D点云对象
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)

    # 生成颜色映射
    colors, min_val, max_val = apply_colormap(values, colormap_name)

    # 设置点云颜色
    pcd.colors = o3d.utility.Vector3dVector(colors)

    # 创建坐标系以便参考
    coordinate_frame = o3d.geometry.TriangleMesh.create_coordinate_frame(
        size=np.max(np.ptp(points, axis=0)) * 0.1, origin=[0, 0, 0])

    # 打印属性统计信息
    print(f"\n{attribute_name} 统计信息:")
    print(f"  数值范围: {min_val:.6f} 到 {max_val:.6f}")
    print(f"  平均值: {np.mean(values):.6f}")
    print(f"  标准差: {np.std(values):.6f}")

    # 可视化
    print(f"\n正在可视化 {attribute_name}...")
    o3d.visualization.draw_geometries([pcd, coordinate_frame])

    return pcd, colors, min_val, max_val


def create_colorbar_image(colormap_name, min_val, max_val, output_path):
    """创建colormap的颜色条图像"""
    fig, ax = plt.subplots(figsize=(4, 1))
    cmap = plt.get_cmap(colormap_name)
    norm = plt.Normalize(min_val, max_val)

    # 创建颜色条
    cb = plt.colorbar(plt.cm.ScalarMappable(norm=norm, cmap=cmap),
                      cax=ax, orientation='horizontal')

    # 设置标签
    cb.set_label('Value')

    # 保存图像
    plt.tight_layout()
    plt.savefig(output_path, dpi=100, bbox_inches='tight')
    plt.close()

    print(f"颜色条已保存到 {output_path}")


def list_available_colormaps():
    """列出所有可用的颜色映射"""
    colormaps = plt.colormaps()
    print("\n可用的颜色映射:")
    # 按类别分组
    categories = {
        "序列型 (Sequential)": ['viridis', 'plasma', 'inferno', 'magma', 'cividis', 'Blues', 'Greens', 'Reds',
                                'YlOrBr'],
        "发散型 (Diverging)": ['coolwarm', 'RdBu', 'RdYlBu', 'RdYlGn', 'PuOr', 'BrBG'],
        "循环型 (Cyclic)": ['twilight', 'twilight_shifted', 'hsv'],
        "定性型 (Qualitative)": ['Pastel1', 'Pastel2', 'Paired', 'Set1', 'Set2', 'tab10', 'tab20']
    }

    for category, cmaps in categories.items():
        print(f"\n  {category}:")
        valid_cmaps = [cmap for cmap in cmaps if cmap in colormaps]
        if valid_cmaps:
            print("    " + ", ".join(valid_cmaps))

    print("\n  其他:")
    other_cmaps = [cmap for cmap in colormaps if not any(cmap in cat_cmaps for cat_cmaps in categories.values())]
    # 每行显示5个
    for i in range(0, len(other_cmaps), 5):
        print("    " + ", ".join(other_cmaps[i:i + 5]))


def main():
    print("=========== 点云属性伪彩色可视化工具 ===========")
    print(f"输入文件: {INPUT_FILE}")
    print(f"输出文件: {OUTPUT_FILE}")
    print(f"选中的属性索引: {ATTRIBUTE_INDEX}")
    print(f"选中的颜色映射: {COLORMAP_NAME}")
    print("===============================================")

    # 确保输入文件存在
    if not os.path.exists(INPUT_FILE):
        print(f"错误: 输入文件 {INPUT_FILE} 不存在!")
        return

    # 创建输出目录（如果不存在）
    output_dir = os.path.dirname(OUTPUT_FILE)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    # 读取点云
    points, attributes, field_names = read_ascii_point_cloud(INPUT_FILE)
    if points is None or attributes is None:
        return

    print(f"成功读取点云: {len(points)}个点")

    # 显示可用属性
    print("\n可用属性:")
    for i, attr_name in enumerate(attributes.keys()):
        print(f"{i}. {attr_name}")

    if not attributes:
        print("未找到可视化属性!")
        return

    # 选择属性
    attr_idx = ATTRIBUTE_INDEX
    if attr_idx < 0 or attr_idx >= len(attributes):
        print(f"警告: 属性索引 {attr_idx} 超出范围，使用第一个属性")
        attr_idx = 0

    attr_name = list(attributes.keys())[attr_idx]
    attr_values = list(attributes.values())[attr_idx]

    # 确认颜色映射名称有效
    colormap_name = COLORMAP_NAME
    if colormap_name not in plt.colormaps():
        print(f"警告: 颜色映射 '{colormap_name}' 不存在，使用默认值 'viridis'")
        colormap_name = 'viridis'

    # 可视化
    pcd, _, min_val, max_val = visualize_point_cloud_with_attribute(
        points, attr_values, attr_name, colormap_name)

    # 保存彩色点云
    o3d.io.write_point_cloud(OUTPUT_FILE, pcd)
    print(f"彩色点云已保存到 {OUTPUT_FILE}")

    # 保存颜色条
    colorbar_path = os.path.splitext(OUTPUT_FILE)[0] + "_colorbar.png"
    create_colorbar_image(colormap_name, min_val, max_val, colorbar_path)


if __name__ == "__main__":
    # 如果需要查看所有可用的颜色映射，取消下一行的注释
    # list_available_colormaps()

    main()