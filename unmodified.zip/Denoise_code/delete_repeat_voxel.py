'用于体素化之后，目的是为了去除体素化后重复的ID，因为可能会出现不同点对应同样的坐标，要确保坐标的唯一性'
import re
from collections import defaultdict

def read_ply(file_path):
    """读取 PLY 文件，分离头部和数据部分"""
    with open(file_path, 'r') as f:
        header = []
        data_start = 0
        for i, line in enumerate(f):
            header.append(line)
            if line.strip() == "end_header":
                data_start = i + 1
                break
        data = pd.read_csv(file_path, skiprows=data_start, sep=' ', header=None)
    return header, data

def detect_and_remove_duplicates(ply_file, output_txt, output_ply):
    # 读取PLY文件中的点
    points = []  # 存储点的坐标 (x, y, z)
    ids = []     # 存储点的 ID
    header_lines = []  # 存储 PLY 文件头部信息

    with open(ply_file, 'r') as file:
        header_ended = False
        for line in file:
            if header_ended:
                coordinates = re.findall(r"[-+]?\d*\.\d+|\d+", line)
                if len(coordinates) >= 4:  # 至少有 x, y, z 和 ID
                    points.append(tuple(map(float, coordinates[:3])))  # 提取 (x, y, z)
                    ids.append(int(float(coordinates[3])))  # 提取 ID，先转 float 再转 int
            else:
                header_lines.append(line)
                if line.startswith("end_header"):
                    header_ended = True

    # 去重并保留第一次出现的点的 ID
    unique_points = {}  # 用于存储去重后的点和其对应的 ID
    for i, point in enumerate(points):
        if point not in unique_points:
            unique_points[point] = ids[i]  # 如果是第一次遇到该点，记录其 ID

    # 保存去重后的数据
    with open(output_ply, 'w') as ply_out:
        # 更新PLY头部信息（修正点数）
        for line in header_lines:
            if line.startswith("element vertex"):
                ply_out.write(f"element vertex {len(unique_points)}\n")
            else:
                ply_out.write(line)

        # 写入去重后的点云和 ID
        for point, id_val in unique_points.items():
            ply_out.write(f"{point[0]} {point[1]} {point[2]} {id_val}\n")

    # 保存重复点统计信息到 TXT 文件
    with open(output_txt, 'w') as txt_file:
        txt_file.write("重复的点云坐标及其出现次数：\n")
        duplicates = len(points) - len(unique_points)
        txt_file.write(f"总重复点数: {duplicates}\n")

    print(f"去重后的PLY文件已保存为 {output_ply}")
    print(f"重复点统计已保存到: {output_txt}")

# 输入与输出文件路径
input_files = [
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/xyz_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fdc012_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fre012_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fre345_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fre678_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fre91011_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fre121314_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fre151617_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fre181920_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fre212223_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fre242526_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fre272829_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fre303132_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fre333435_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fre363738_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fre394041_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fre424344_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/fre4344op_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/scale012_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/rot012_ascii_voxel.ply',
'/home/acc/Desktop/带背景高斯点云/toy2/体素化/rot123_ascii_voxel.ply'


]

output_dir = '/home/acc/Desktop/带背景高斯点云/toy2/体素后去重/'

# 执行去重流程
for input_ply in input_files:
    file_name = input_ply.split('/')[-1].replace('.ply', '')
    output_txt_path = f"{output_dir}{file_name}_rp.txt"
    output_ply_path = f"{output_dir}{file_name}_norp.ply"

    detect_and_remove_duplicates(input_ply, output_txt_path, output_ply_path)
