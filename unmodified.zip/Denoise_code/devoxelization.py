import os
import numpy as np
import pandas as pd

def get_min_max_coordinates(file_path):
    """从点云文件中获取坐标的最小值和最大值"""
    with open(file_path, 'r') as f:
        data_start = 0
        for i, line in enumerate(f):
            if line.strip() == "end_header":
                data_start = i + 1
                break
    data = pd.read_csv(file_path, skiprows=data_start, sep=' ', header=None)
    xyz = data.iloc[:, :3].values
    xyz_min = xyz.min(axis=0)
    xyz_max = xyz.max(axis=0)
    return xyz_min, xyz_max

def read_voxelized_ply(file_path):
    """读取体素化后的 PLY 文件，分离头部和数据部分"""
    with open(file_path, 'r') as f:
        header = []
        data_start = 0
        for i, line in enumerate(f):
            header.append(line)
            if line.strip() == "end_header":
                data_start = i + 1
                break
        data = pd.read_csv(file_path, skiprows=data_start, sep=' ', header=None)
    return header, data

def devoxelize(data, voxel_resolution, original_min, original_max):
    """反体素化操作，将体素网格坐标还原为近似原始坐标"""
    # 提取体素网格坐标
    voxel_coords = data.iloc[:, :3].values
    attributes = data.iloc[:, 3:-1].values  # 其他属性
    ids = data.iloc[:, -1].values          # 点 ID

    # 归一化范围 [0, 1]
    normalized_coords = voxel_coords / voxel_resolution

    # 反归一化到原始坐标范围
    original_coords = normalized_coords * (original_max - original_min) + original_min

    # 拼接恢复的坐标、属性和 ID
    restored_data = np.hstack((original_coords, attributes, ids.reshape(-1, 1)))
    return restored_data

def write_devoxelized_ply(output_path, header, restored_data):
    """将反体素化后的数据保存为 PLY 文件，保留与输入文件相同的头部"""
    with open(output_path, 'w') as f:
        for line in header:
            f.write(line)
        for row in restored_data:
            row = list(row)
            row[:-1] = map(str, row[:-1])  # 保留坐标和属性为字符串
            row[-1] = str(int(row[-1]))   # 强制将 ID 转为整数
            f.write(' '.join(row) + '\n')

def process_files(original_ply_path, voxelized_ply_path, output_ply_path, voxel_resolution):
    """处理每一对文件路径，执行反体素化操作"""
    # 获取原始点云的最小值和最大值
    xyz_min, xyz_max = get_min_max_coordinates(original_ply_path)
    print(f"Processing: {original_ply_path} -> {voxelized_ply_path} -> {output_ply_path}")
    print("最小值 (xyz_min):", xyz_min)
    print("最大值 (xyz_max):", xyz_max)

    # 读取体素化点云文件
    header, voxel_data = read_voxelized_ply(voxelized_ply_path)

    # 执行反体素化操作
    restored_data = devoxelize(voxel_data, voxel_resolution, xyz_min, xyz_max)

    # 保存反体素化后的点云文件
    write_devoxelized_ply(output_ply_path, header, restored_data)
    print(f"反体素化后的点云数据已保存至: {output_ply_path}")

def main():
    # 示例路径列表，实际情况可以根据需求进行修改
    # 假设用户提供了多个原始点云文件、体素化文件和输出路径

    # 可以在此定义多个路径对，例如：
    file_pairs = [
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/xyz_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/xyz_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/xyz_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fdc012_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fdc012_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fdc012_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre012_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fre012_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre012_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre345_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fre345_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre345_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre678_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fre678_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre678_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre91011_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fre91011_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre91011_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre121314_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fre121314_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre121314_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre151617_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fre151617_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre151617_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre181920_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fre181920_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre181920_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre212223_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fre212223_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre212223_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre242526_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fre242526_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre242526_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre272829_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fre272829_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre272829_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre303132_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fre303132_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre303132_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre333435_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fre333435_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre333435_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre363738_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fre363738_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre363738_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre394041_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fre394041_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre394041_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre424344_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fre424344_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre424344_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/fre4344op_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/fre4344op_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/fre4344op_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/rot012_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/rot012_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/rot012_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/rot123_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/rot123_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/rot123_ascii_voxeltopc.ply'),
        ('/home/acc/Desktop/带背景高斯点云/toy2/拆分/scale012_ascii.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/点云重建后/scale012_ascii_voxel_re.ply',
         '/home/acc/Desktop/带背景高斯点云/toy2/对齐/scale012_ascii_voxeltopc.ply')

        # 添加更多路径对
    ]

    # 体素网格分辨率
    voxel_resolution = 7168

    # 遍历所有路径对，处理每个文件对
    for original_ply_path, voxelized_ply_path, output_ply_path in file_pairs:
        process_files(original_ply_path, voxelized_ply_path, output_ply_path, voxel_resolution)

if __name__ == "__main__":
    main()
