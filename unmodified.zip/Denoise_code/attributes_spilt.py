'从ascii编码的点云文件中以三个为一组，筛选出属性值文件。'
'注意，nxyz.py不知道什么原因，会产生非0的数值，它应当为0（因为我看了多个点云数据法向量都是0），直接删除产生的nxyz.py文件就好。若本身不为0，这条提示可忽略'
import os
import numpy as np
import pandas as pd
from tqdm import tqdm  # 导入进度条库

def read_ply(file_path):
    """读取 PLY 文件，分离头部和数据部分"""
    with open(file_path, 'r') as f:
        header = []
        data_start = 0
        for i, line in enumerate(f):
            header.append(line)
            if line.strip() == "end_header":
                data_start = i + 1
                break
        data = pd.read_csv(file_path, skiprows=data_start, sep=' ', header=None)
    return header, data

def add_unique_id(data):
    """
    为每一行数据添加唯一ID。
    :param data: 输入的DataFrame数据。
    :return: 带ID的DataFrame数据。
    """
    data['ID'] = range(len(data))  # 添加ID列，值从0开始
    return data

def filter_ply_columns(header, data, columns_to_keep):
    """
    筛选指定列数据，并更新头部信息。
    :param header: 原始头部信息
    :param data: 数据部分
    :param columns_to_keep: 要保留的列索引列表
    :return: 更新后的头部和数据
    """
    # 添加ID列，确保ID列最后一位
    data = add_unique_id(data)
    columns_to_keep = columns_to_keep + [-1]  # 添加ID列索引
    filtered_data = data.iloc[:, columns_to_keep]

    # 更新头部信息
    updated_header = []
    property_lines = []
    keep_index = 0
    for line in header:
        if line.startswith("property"):
            if keep_index in columns_to_keep:
                property_lines.append(line)
            keep_index += 1
        elif line.startswith("element vertex"):
            element_vertex_line = f"element vertex {len(filtered_data)}\n"
            updated_header.append(element_vertex_line)
        elif line.startswith("format") or line.startswith("ply") or line.startswith("end_header"):
            updated_header.append(line)
        else:
            updated_header.append(line)

    # 添加ID列描述到头部
    property_lines.append("property int ID\n")
    updated_header = updated_header[:3] + property_lines + ["end_header\n"]

    return updated_header, filtered_data

def write_ply(output_path, header, filtered_data):
    """保存筛选后的数据为 PLY 文件"""
    with open(output_path, 'w') as f:
        for line in header:
            f.write(line)
        for row in filtered_data.itertuples(index=False):
            f.write(' '.join(map(str, row)) + '\n')

# 参数设置
input_ply = '/home/acc/Desktop/带背景高斯点云/toy2/toy2_ascii.ply'  # 输入 PLY 文件路径
output_dir = '/home/acc/Desktop/带背景高斯点云/toy2/拆分/'  # 输出文件夹路径
columns_to_keep_list = [
    ([0, 1, 2], "xyz_ascii"),  # x, y, z
    ([3, 4, 5], "nxyz_ascii"),  # nxyz
    ([6, 7, 8], "fdc012_ascii"),  # fdc012
    ([9, 10, 11], "fre012_ascii"), # fre012~
    ([12, 13, 14], "fre345_ascii"),
    ([15, 16, 17], "fre678_ascii"),
    ([18, 19, 20], "fre91011_ascii"),
    ([21, 22, 23], "fre121314_ascii"),
    ([24, 25, 26], "fre151617_ascii"),
    ([27, 28, 29], "fre181920_ascii"),
    ([30, 31, 32], "fre212223_ascii"),
    ([33, 34, 35], "fre242526_ascii"),
    ([36, 37, 38], "fre272829_ascii"),
    ([39, 40, 41], "fre303132_ascii"),
    ([42, 43, 44], "fre333435_ascii"),
    ([45, 46, 47], "fre363738_ascii"),
    ([48, 49, 50], "fre394041_ascii"),
    ([51, 52, 53], "fre424344_ascii"),  # ~fre424344
    ([52, 53, 54], "fre4344op_ascii"),  # fre4344opacity
    ([55, 56, 57], "scale012_ascii"), # scale012
    ([58, 59, 60], "rot012_ascii"),   # rot012
    ([59, 60, 61], "rot123_ascii")    # rot123
]  # 定义多个 columns_to_keep 参数及其对应的文件名后缀

# 执行流程
header, data = read_ply(input_ply)
for columns_to_keep, name_suffix in tqdm(columns_to_keep_list, desc="Processing columns", ncols=100):
    updated_header, filtered_data = filter_ply_columns(header, data, columns_to_keep)
    output_ply = f"{output_dir}{name_suffix}.ply"  # 输出文件路径，使用自定义名称
    write_ply(output_ply, updated_header, filtered_data)
    print(f"带ID的PLY文件已保存至: {output_ply}")
